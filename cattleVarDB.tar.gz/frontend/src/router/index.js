/**
 * ============================================
 * Vue Router Configuration
 * ============================================
 */

import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/SNPTableView.vue'),
    meta: { title: '牛SNP效应值数据库' }
  },
  {
    path: '/snps',
    name: 'SNPList',
    component: () => import('../views/SNPTableView.vue'),
    meta: { title: 'SNP列表' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Set page title
router.beforeEach((to, from, next) => {
  document.title = to.meta.title || '牛SNP效应值数据库'
  next()
})

export default router
