<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script setup>
// Main App Component
</script>

<style>
/* Global styles will be imported in main.js */
</style>
