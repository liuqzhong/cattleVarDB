<template>
  <div class="snp-table-view">
    <!-- Header -->
    <div class="page-header">
      <h1>
        <el-icon><Collection /></el-icon>
        牛SNP效应值数据库
      </h1>
      <p class="subtitle">Cattle SNP Effect Value Database</p>
    </div>

    <!-- Stats Cards -->
    <div class="stats-container">
      <el-row :gutter="20">
        <el-col :xs="24" :sm="12" :md="8">
          <el-card shadow="hover" class="stat-card">
            <div class="stat-content">
              <el-icon class="stat-icon" color="#409EFF"><Document /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ stats.total_snps || '-' }}</div>
                <div class="stat-label">SNP总数</div>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8">
          <el-card shadow="hover" class="stat-card">
            <div class="stat-content">
              <el-icon class="stat-icon" color="#67C23A"><Grid /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ stats.total_targets || '-' }}</div>
                <div class="stat-label">靶点数</div>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8">
          <el-card shadow="hover" class="stat-card">
            <div class="stat-content">
              <el-icon class="stat-icon" color="#E6A23C"><DataLine /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ formatNumber(stats.total_effect_records) || '-' }}</div>
                <div class="stat-label">效应值记录</div>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- Search and Filter -->
    <el-card shadow="never" class="search-card">
      <el-row :gutter="20">
        <el-col :xs="24" :sm="16" :md="18">
          <el-input
            v-model="searchQuery"
            placeholder="搜索SNP (chr:位置 或 rsID，如 chr1:15449431)"
            clearable
            @clear="handleClearSearch"
            @keyup.enter="handleSearch"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
            <template #append>
              <el-button @click="handleSearch" :loading="loading">
                搜索
              </el-button>
            </template>
          </el-input>
        </el-col>
        <el-col :xs="24" :sm="8" :md="6">
          <el-select v-model="pageSize" @change="handlePageSizeChange" style="width: 100%">
            <el-option label="10 条/页" :value="10" />
            <el-option label="20 条/页" :value="20" />
            <el-option label="50 条/页" :value="50" />
            <el-option label="100 条/页" :value="100" />
          </el-select>
        </el-col>
      </el-row>
    </el-card>

    <!-- Data Table -->
    <el-card shadow="never" class="table-card" v-loading="loading">
      <el-table
        :data="tableData"
        stripe
        border
        style="width: 100%"
        :default-sort="{ prop: 'id', order: 'ascending' }"
        @sort-change="handleSortChange"
        :empty-text="searchMode ? '未找到匹配的SNP' : '暂无数据'"
      >
        <el-table-column prop="id" label="ID" width="80" sortable="custom" />
        <el-table-column prop="chrom" label="染色体" width="100" sortable="custom" />
        <el-table-column prop="pos" label="位置" width="120" sortable="custom">
          <template #default="{ row }">
            <el-tag size="small">{{ formatNumber(row.pos) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="rs_id" label="rsID" width="150">
          <template #default="{ row }">
            <span v-if="row.rs_id" class="rs-id">{{ row.rs_id }}</span>
            <span v-else class="text-muted">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="ref_allele" label="参考碱基" width="100" align="center">
          <template #default="{ row }">
            <el-tag type="info" size="small">{{ row.ref_allele }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="alt_allele" label="变异碱基" width="100" align="center">
          <template #default="{ row }">
            <el-tag type="warning" size="small">{{ row.alt_allele }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="max_abs_sad" label="最大绝对SAD值" width="150" sortable="custom">
          <template #default="{ row }">
            <span class="sad-value">{{ row.max_abs_sad.toFixed(6) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              size="small"
              link
              @click="handleViewDetail(row)"
            >
              详情
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- Pagination -->
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="handlePageChange"
          @size-change="handlePageSizeChange"
        />
      </div>
    </el-card>

    <!-- Detail Dialog -->
    <el-dialog
      v-model="detailDialogVisible"
      title="SNP详情"
      width="70%"
      :close-on-click-modal="false"
    >
      <div v-if="currentSnp" class="snp-detail">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="ID">{{ currentSnp.id }}</el-descriptions-item>
          <el-descriptions-item label="rsID">{{ currentSnp.rs_id || '-' }}</el-descriptions-item>
          <el-descriptions-item label="染色体">{{ currentSnp.chrom }}</el-descriptions-item>
          <el-descriptions-item label="位置">{{ formatNumber(currentSnp.pos) }}</el-descriptions-item>
          <el-descriptions-item label="参考碱基">
            <el-tag type="info">{{ currentSnp.ref_allele }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="变异碱基">
            <el-tag type="warning">{{ currentSnp.alt_allele }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="最大绝对SAD值" :span="2">
            <span class="sad-value-large">{{ currentSnp.max_abs_sad.toFixed(8) }}</span>
          </el-descriptions-item>
        </el-descriptions>

        <el-divider>效应值数据</el-divider>

        <div v-loading="effectLoading" class="effects-container">
          <el-alert
            v-if="!effectLoading && (!currentSnp.effect_values || currentSnp.effect_values.length === 0)"
            title="暂无效应值数据"
            type="info"
            :closable="false"
          />
          <el-table
            v-else
            :data="currentSnp.effect_values"
            stripe
            max-height="400"
            :default-sort="{ prop: 'effect_value', order: 'descending' }"
          >
            <el-table-column
              prop="target_name"
              label="靶点名称"
              width="300"
            />
            <el-table-column
              prop="effect_value"
              label="效应值"
              sortable
            >
              <template #default="{ row }">
                <span :class="getEffectValueClass(row.effect_value)">
                  {{ row.effect_value.toFixed(6) }}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { snpApi, statsApi } from '../services/api'

// Data
const loading = ref(false)
const effectLoading = ref(false)
const searchMode = ref(false)
const tableData = ref([])
const stats = ref({})

// Pagination
const currentPage = ref(1)
const pageSize = ref(20)
const total = ref(0)

// Search
const searchQuery = ref('')

// Sort
const sortBy = ref('id')
const sortOrder = ref('asc')

// Detail dialog
const detailDialogVisible = ref(false)
const currentSnp = ref(null)

// Methods
const formatNumber = (num) => {
  return num ? num.toLocaleString() : '-'
}

const getEffectValueClass = (value) => {
  const absValue = Math.abs(value)
  if (absValue > 0.1) return 'effect-high'
  if (absValue > 0.05) return 'effect-medium'
  return 'effect-low'
}

const fetchStats = async () => {
  try {
    const data = await statsApi.getStats()
    stats.value = data
  } catch (error) {
    console.error('Failed to fetch stats:', error)
  }
}

const fetchSNPs = async () => {
  loading.value = true
  try {
    const params = {
      page: currentPage.value,
      page_size: pageSize.value,
      sort_by: sortBy.value,
      sort_order: sortOrder.value
    }

    const response = searchMode.value && searchQuery.value
      ? await snpApi.search(searchQuery.value, params)
      : await snpApi.getList(params)

    tableData.value = response.data
    total.value = response.total
  } catch (error) {
    ElMessage.error(`加载数据失败: ${error.message}`)
  } finally {
    loading.value = false
  }
}

const handleSearch = () => {
  if (!searchQuery.value.trim()) {
    ElMessage.warning('请输入搜索关键词')
    return
  }
  searchMode.value = true
  currentPage.value = 1
  fetchSNPs()
}

const handleClearSearch = () => {
  searchMode.value = false
  searchQuery.value = ''
  currentPage.value = 1
  fetchSNPs()
}

const handlePageChange = (page) => {
  currentPage.value = page
  fetchSNPs()
}

const handlePageSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
  fetchSNPs()
}

const handleSortChange = ({ prop, order }) => {
  sortBy.value = prop || 'id'
  sortOrder.value = order === 'descending' ? 'desc' : 'asc'
  fetchSNPs()
}

const handleViewDetail = async (row) => {
  currentSnp.value = { ...row, effect_values: [] }
  detailDialogVisible.value = true
  effectLoading.value = true

  try {
    const detail = await snpApi.getDetail(row.id)
    currentSnp.value = detail
  } catch (error) {
    ElMessage.error(`加载详情失败: ${error.message}`)
  } finally {
    effectLoading.value = false
  }
}

// Lifecycle
onMounted(() => {
  fetchStats()
  fetchSNPs()
})
</script>

<style scoped>
.snp-table-view {
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.page-header {
  text-align: center;
  margin-bottom: 30px;
}

.page-header h1 {
  font-size: 28px;
  color: #303133;
  margin: 0 0 10px 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}

.stats-container {
  margin-bottom: 20px;
}

.stat-card {
  height: 100%;
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 15px;
}

.stat-icon {
  font-size: 36px;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.stat-label {
  font-size: 14px;
  color: #909399;
}

.search-card {
  margin-bottom: 20px;
}

.table-card {
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.rs-id {
  font-family: 'Courier New', monospace;
  color: #409EFF;
  font-weight: 500;
}

.text-muted {
  color: #C0C4CC;
}

.sad-value {
  font-family: 'Courier New', monospace;
  font-weight: 500;
}

.sad-value-large {
  font-family: 'Courier New', monospace;
  font-size: 18px;
  font-weight: bold;
  color: #409EFF;
}

.effects-container {
  margin-top: 20px;
}

.effect-high {
  color: #F56C6C;
  font-weight: bold;
}

.effect-medium {
  color: #E6A23C;
  font-weight: 500;
}

.effect-low {
  color: #909399;
}

@media (max-width: 768px) {
  .snp-table-view {
    padding: 10px;
  }

  .page-header h1 {
    font-size: 20px;
  }

  .stat-value {
    font-size: 18px;
  }
}
</style>
