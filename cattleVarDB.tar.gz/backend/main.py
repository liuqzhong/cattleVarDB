"""
============================================
Cattle SNP Effect Value Database - Backend API
牛变异效应值数据库 - 后端API
============================================

Technology: FastAPI + SQLAlchemy + PostgreSQL
Author: Generated based on requirements
"""

from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine, Column, Integer, String, Float, BigInteger, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.dialects.postgresql import insert as pg_insert
from typing import Optional, List
from pydantic import BaseModel, Field
from datetime import datetime
import logging
import os
import re

# ============================================
# Configuration
# ============================================
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://cattle_user:cattle_pass@localhost:5432/cattle_snp_db"
)

# ============================================
# Logging Setup
# ============================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================
# Database Setup
# ============================================
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ============================================
# Database Models
# ============================================
class SNPModel(Base):
    """SNP基础信息表"""
    __tablename__ = "snps"

    id = Column(Integer, primary_key=True, index=True)
    chrom = Column(String(10), nullable=False, index=True)
    pos = Column(BigInteger, nullable=False, index=True)
    rs_id = Column(String(100), nullable=True, index=True)
    ref_allele = Column(String(10), nullable=False)
    alt_allele = Column(String(10), nullable=False)
    max_abs_sad = Column(Float, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class TargetModel(Base):
    """靶点（组织/细胞类型）表"""
    __tablename__ = "targets"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True)
    category = Column(String(100), nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SNPEffectModel(Base):
    """SNP效应值表"""
    __tablename__ = "snp_effects"

    id = Column(BigInteger, primary_key=True, index=True)
    snp_id = Column(Integer, nullable=False, index=True)
    target_id = Column(Integer, nullable=False, index=True)
    effect_value = Column(Float, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================
# Pydantic Schemas
# ============================================
class SNPBase(BaseModel):
    """SNP基础Schema"""
    chrom: str = Field(..., description="染色体 (如 chr1)")
    pos: int = Field(..., description="位置", gt=0)
    rs_id: Optional[str] = Field(None, description="dbSNP ID (如 rs1115118696)")
    ref_allele: str = Field(..., description="参考碱基")
    alt_allele: str = Field(..., description="变异碱基")
    max_abs_sad: float = Field(..., description="最大绝对SAD值")


class SNPResponse(SNPBase):
    """SNP响应Schema"""
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class SNPPaginatedResponse(BaseModel):
    """分页响应Schema"""
    total: int = Field(..., description="总记录数")
    page: int = Field(..., description="当前页码")
    page_size: int = Field(..., description="每页大小")
    total_pages: int = Field(..., description="总页数")
    data: List[SNPResponse] = Field(..., description="SNP数据列表")


class SNPDetailResponse(SNPResponse):
    """SNP详情响应Schema（包含效应值）"""
    effect_values: List[dict] = Field(default=[], description="效应值列表")


class EffectValueResponse(BaseModel):
    """单个效应值响应"""
    target_name: str
    effect_value: float


class ErrorResponse(BaseModel):
    """错误响应Schema"""
    error: str = Field(..., description="错误类型")
    message: str = Field(..., description="错误消息")
    detail: Optional[str] = Field(None, description="详细错误信息")


class HealthResponse(BaseModel):
    """健康检查响应"""
    status: str
    database: str
    timestamp: datetime


# ============================================
# FastAPI App Initialization
# ============================================
app = FastAPI(
    title="Cattle SNP Effect Value Database API",
    description="牛变异效应值数据库 - RESTful API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================
# Database Dependency
# ============================================
def get_db():
    """获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============================================
# Utility Functions
# ============================================
def parse_chrom_pos(query: str) -> Optional[tuple]:
    """
    解析染色体:位置格式的查询字符串
    如: "chr1:15449431" -> ("chr1", 15449431)
    """
    pattern = r'^[cC][hH][rR]([0-9XYxy]+):([0-9]+)$'
    match = re.match(pattern, query.strip())
    if match:
        chrom = "chr" + match.group(1).upper()
        pos = int(match.group(2))
        return chrom, pos
    return None


def calculate_total_pages(total: int, page_size: int) -> int:
    """计算总页数"""
    return (total + page_size - 1) // page_size if page_size > 0 else 0


# ============================================
# API Endpoints
# ============================================

@app.get("/", response_model=dict)
async def root():
    """API根路径"""
    return {
        "message": "Cattle SNP Effect Value Database API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc"
    }


@app.get("/health", response_model=HealthResponse)
async def health_check(db: Session = Depends(get_db)):
    """健康检查接口"""
    try:
        # Test database connection
        db.execute("SELECT 1")
        return HealthResponse(
            status="healthy",
            database="connected",
            timestamp=datetime.utcnow()
        )
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database connection failed"
        )


@app.get("/snps", response_model=SNPPaginatedResponse)
async def get_snps(
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=1, le=100, description="每页大小"),
    sort_by: str = Query("id", description="排序字段"),
    sort_order: str = Query("asc", pattern="^(asc|desc)$", description="排序方向"),
    db: Session = Depends(get_db)
):
    """
    获取SNP列表（分页）

    - **page**: 页码，从1开始
    - **page_size**: 每页大小，最大100
    - **sort_by**: 排序字段（id, chrom, pos, max_abs_sad等）
    - **sort_order**: 排序方向（asc或desc）
    """
    try:
        # Build query
        query = db.query(SNPModel)

        # Get total count
        total = query.count()

        # Apply sorting
        sort_column = getattr(SNPModel, sort_by, SNPModel.id)
        if sort_order == "desc":
            query = query.order_by(sort_column.desc())
        else:
            query = query.order_by(sort_column.asc())

        # Apply pagination
        offset = (page - 1) * page_size
        snps = query.offset(offset).limit(page_size).all()

        # Calculate total pages
        total_pages = calculate_total_pages(total, page_size)

        return SNPPaginatedResponse(
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            data=snps
        )

    except Exception as e:
        logger.error(f"Error fetching SNPs: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch SNPs: {str(e)}"
        )


@app.get("/snps/search", response_model=SNPPaginatedResponse)
async def search_snps(
    query: str = Query(..., min_length=1, description="搜索查询 (chr:position 或 rsID)"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=1, le=100, description="每页大小"),
    db: Session = Depends(get_db)
):
    """
    搜索SNP

    支持两种搜索格式:
    - **chr:position**: 如 "chr1:15449431" (精确匹配)
    - **rsID**: 如 "rs1115118696" (模糊匹配)
    """
    try:
        search_query = db.query(SNPModel)

        # Try to parse as chrom:position format
        chrom_pos = parse_chrom_pos(query)
        if chrom_pos:
            chrom, pos = chrom_pos
            search_query = search_query.filter(
                SNPModel.chrom == chrom,
                SNPModel.pos == pos
            )
            logger.info(f"Searching by chrom:pos - {chrom}:{pos}")
        else:
            # Search by rs_id (fuzzy match)
            search_query = search_query.filter(
                SNPModel.rs_id.ilike(f"%{query}%")
            )
            logger.info(f"Searching by rs_id - {query}")

        # Get total count
        total = search_query.count()

        # Apply pagination
        offset = (page - 1) * page_size
        results = search_query.offset(offset).limit(page_size).all()

        total_pages = calculate_total_pages(total, page_size)

        return SNPPaginatedResponse(
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            data=results
        )

    except Exception as e:
        logger.error(f"Error searching SNPs: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Search failed: {str(e)}"
        )


@app.get("/snps/{snp_id}", response_model=SNPDetailResponse)
async def get_snp_detail(
    snp_id: int,
    db: Session = Depends(get_db)
):
    """
    获取SNP详情（包含效应值）

    - **snp_id**: SNP数据库ID
    """
    try:
        # Get SNP basic info
        snp = db.query(SNPModel).filter(SNPModel.id == snp_id).first()
        if not snp:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"SNP with id {snp_id} not found"
            )

        # Get effect values with target names
        effects = db.query(
            SNPEffectModel.effect_value,
            TargetModel.name
        ).join(
            TargetModel, SNPEffectModel.target_id == TargetModel.id
        ).filter(
            SNPEffectModel.snp_id == snp_id
        ).all()

        effect_values = [
            {"target_name": effect.name, "effect_value": effect.effect_value}
            for effect in effects
        ]

        return SNPDetailResponse(
            **snp.__dict__,
            effect_values=effect_values
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching SNP detail: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch SNP detail: {str(e)}"
        )


@app.get("/targets", response_model=List[dict])
async def get_targets(
    skip: int = Query(0, ge=0, description="跳过记录数"),
    limit: int = Query(100, ge=1, le=500, description="返回记录数"),
    db: Session = Depends(get_db)
):
    """
    获取靶点（组织/细胞类型）列表

    - **skip**: 跳过的记录数
    - **limit**: 返回的记录数
    """
    try:
        targets = db.query(TargetModel).offset(skip).limit(limit).all()
        return [
            {
                "id": t.id,
                "name": t.name,
                "category": t.category,
                "description": t.description
            }
            for t in targets
        ]
    except Exception as e:
        logger.error(f"Error fetching targets: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch targets: {str(e)}"
        )


@app.get("/stats", response_model=dict)
async def get_statistics(db: Session = Depends(get_db)):
    """
    获取数据库统计信息
    """
    try:
        snp_count = db.query(SNPModel).count()
        target_count = db.query(TargetModel).count()
        effect_count = db.query(SNPEffectModel).count()

        return {
            "total_snps": snp_count,
            "total_targets": target_count,
            "total_effect_records": effect_count,
            "data_timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching statistics: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch statistics: {str(e)}"
        )


# ============================================
# Exception Handlers
# ============================================
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """HTTP异常处理"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "http_error",
            "message": exc.detail,
            "status_code": exc.status_code
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """通用异常处理"""
    logger.error(f"Unhandled exception: {str(exc)}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "internal_error",
            "message": "An unexpected error occurred",
            "detail": str(exc)
        }
    )


# ============================================
# Startup Event
# ============================================
@app.on_event("startup")
async def startup_event():
    """应用启动事件"""
    logger.info("Starting Cattle SNP Effect Value Database API...")
    logger.info(f"Database URL: {DATABASE_URL}")


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭事件"""
    logger.info("Shutting down Cattle SNP Effect Value Database API...")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
