"""
Cattle SNP Effect Value Database - Backend Package
牛变异效应值数据库 - 后端包
"""
